Put the Mono folder in this folder:
C:\Program Files\Reference Assemblies\Microsoft\Framework\.NETFramework\v4.0\Profile

Now run the mono.registration.reg to register the framework on a 32 bit system or the mono.registration.x64.reg on a 64 bit system.